package ar.edu.itba.pod.concurrency.e4;

import java.util.Arrays;
import java.util.Random;
import java.util.function.Consumer;

import org.junit.Test;

/**
 * Benchmar to compare between {@link Arrays#parallelSort(int[])} and
 * {@link Arrays#sort(int[])}
 */
public class SortBenchmark {

    @Test
    public void benchmark_all() {

    }

}
