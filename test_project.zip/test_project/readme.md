# Fast Running

Correr el comando en 1 terminal:
```
cd server/target/ && tar -xzf test_project-server-1.0-SNAPSHOT-bin.tar.gz && cd test_project-server-1.0-SNAPSHOT && chmod u+x run-server.sh && chmod u+x run-registry.sh
```

En otra terminal correr:
```
cd client/target/ && tar -xzf test_project-client-1.0-SNAPSHOT-bin.tar.gz && cd test_project-client-1.0-SNAPSHOT && chmod u+x run-client.sh
```

Movimiento de directorios rapido:
```
cd server/target/test_project-server-1.0-SNAPSHOT
```