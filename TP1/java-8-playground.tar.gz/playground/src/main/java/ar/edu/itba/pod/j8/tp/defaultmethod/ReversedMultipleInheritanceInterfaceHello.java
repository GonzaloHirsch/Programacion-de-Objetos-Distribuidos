
package ar.edu.itba.pod.j8.tp.defaultmethod;

/**
 * One of 2 classes (the other {@link MultipleInheritanceInterfaceHello}) to test inheritance with to
 * interfaces (dependant) that define the same default method.
 *
 * @author Marcelo
 * @since Jul 30, 2015
 */
public class ReversedMultipleInheritanceInterfaceHello implements OverridingHelloInterface, BaseHelloInterfaz {

}
